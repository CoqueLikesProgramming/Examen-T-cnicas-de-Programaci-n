public class Canoe extends Ship {
    public Canoe(final CardinalPoints direction, final Point startPoint) {
        super(3, direction, startPoint);
    }
}
