public class Point {
    private int x;
    private int y;

    public Point(final int x, final int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return this.x;
    }

    public void setX(final int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(final int y) {
        this.y = y;
    }

    public Point[] getShip(final int size, final CardinalPoints direction) {
        final Point[] ship = new Point[size];
        ship[0] = this;

        for (int i = 1; i < size; i++) {
            switch (direction) {
                case NORTH:
                    ship[i] = new Point(this.x, this.y - i);
                    break;
                case SOUTH:
                    ship[i] = new Point(this.x, this.y + i);
                    break;
                case EAST:
                    ship[i] = new Point(this.x + i, this.y);
                    break;
                case WEST:
                    ship[i] = new Point(this.x - i, this.y);
                    break;
            }
        }
        return ship;
    }
}
