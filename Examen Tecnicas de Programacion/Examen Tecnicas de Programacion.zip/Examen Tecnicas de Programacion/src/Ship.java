public class Ship {
    private int size;
    private CardinalPoints direction;
    private Point startingPoint;
    private boolean isSunk;

    public Ship(final int size, final CardinalPoints direction, final Point startingPoint) {
        this.size = size;
        this.direction = direction;
        this.startingPoint = startingPoint;
        isSunk = false;
    }

    public int getSize() {
        return this.size;
    }

    public void setSize(final int size) {
        this.size = size;
    }

    public CardinalPoints getDirection() {
        return this.direction;
    }

    public void setDirection(final CardinalPoints direction) {
        this.direction = direction;
    }

    public Point getStartingPoint() {
        return this.startingPoint;
    }

    public void setStartingPoint(final Point startingPoint) {
        this.startingPoint = startingPoint;
    }

    public boolean isSunk() {
        return this.isSunk;
    }

    public void setSunk(final boolean isSunk) {
        this.isSunk = isSunk;
    }

    public boolean getShot(final Point shotPoint) {
        final Point[] shipPoints = this.startingPoint.getShip(this.size, this.direction);

        for (final Point point : shipPoints) {
            if (point.getX() == shotPoint.getX() && point.getY() == shotPoint.getY()) {
                return true;
            }
        }
        return false;
    }
}
