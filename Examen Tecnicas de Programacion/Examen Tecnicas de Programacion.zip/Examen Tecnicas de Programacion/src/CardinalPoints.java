public enum CardinalPoints {
    NORTH, EAST, SOUTH, WEST
}
