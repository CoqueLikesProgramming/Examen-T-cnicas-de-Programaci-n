public class Frigate extends Ship {
    public Frigate(final CardinalPoints direction, final Point startPoint) {
        super(1, direction, startPoint);
    }
}
