public class Battleship extends Ship {
    private final boolean[] isolated;  // true en la posición aislada, false en las demás
    private int isolatedCount;  // cantidad de posiciones aisladas aún no tocadas

    public Battleship(int startPoint, CardinalPoints direction) {
        super(startPoint, direction, 5);
        isolated = new boolean[5];
        isolated[2] = true;  // posición aislada del medio
        isolatedCount = 1;
    }

    public boolean getIsolated(int index) {
        return isolated[index];
    }

    @Override
    public boolean getShot(Point shotPoint) {
        boolean hit = super.getShot(shotPoint);
        if (hit) {
            int index = getPositionIndex(shotPoint);
            if (isolated[index]) {
                isolated[index] = false;
                isolatedCount--;
                if (0 == this.isolatedCount) {
                    setSunk(true);
                }
            }
        }
        return hit;
    }
}
